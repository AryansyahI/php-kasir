<?php

namespace App\Filament\Resources\ProducResource\Pages;

use App\Filament\Resources\ProducResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateProduc extends CreateRecord
{
    protected static string $resource = ProducResource::class;
}
